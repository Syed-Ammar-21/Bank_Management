
package bank_management_system;

public class Bank_Management_System {

  public static void main(String[] args) {

    f3 mr = new f3();
    mr.setVisible(true);

  }

}